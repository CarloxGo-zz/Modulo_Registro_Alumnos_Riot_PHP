            </div>
        </div>            

            <div class="row">
                <div class="col-xs-12">
                    <footer class="text-center">
                        <hr />
                        <p>Ejemplo desarrollado por <a href="http://anexsoft.com">Anexsoft</a></p>                
                    </footer>                
                </div>    
            </div>
        </div>

        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery-ui/jquery-ui.min.js"></script>
        <script src="assets/js/jquery.anexsoft-validator.js"></script>
        <script src="https://cdn.rawgit.com/Anexsoft/AnexGRID/master/jquery.anexgrid.min.js"></script>

        <script src="assets/js/riotjs/riot.min.js"></script>
        <script src="assets/js/riotjs/riot-compiler.min.js"></script>

        <script src="assets/js/ini.js"></script>
    </body>
</html>